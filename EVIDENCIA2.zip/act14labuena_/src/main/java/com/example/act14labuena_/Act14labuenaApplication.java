package com.example.act14labuena_;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
class Act14labuena_Application {

    public static void main(String[] args) {
        SpringApplication.run(Act14labuenaApplication.class, args);
    }

    @SpringBootApplication
    public static class Act14labuenaApplication {

        public static void main(String[] args) {
            SpringApplication.run(Act14labuenaApplication.class, args);
        }

    }
}
