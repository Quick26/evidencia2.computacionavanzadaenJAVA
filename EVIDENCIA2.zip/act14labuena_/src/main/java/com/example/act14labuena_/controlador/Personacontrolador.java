package com.example.act14labuena_.controlador;


import com.example.act14labuena_.model.HistoricoIMC;
import com.example.act14labuena_.model.entidad_persona;
import com.example.act14labuena_.servicio.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.management.remote.JMXAuthenticator;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/PERSONITAS")
public class Personacontrolador {

    @Autowired
    private service personasService;
    private JMXAuthenticator authservice;

    @GetMapping
    public ArrayList<entidad_persona> getPersonas(){
        return this.personasService.getPersonas();
    }

    @PostMapping
    public entidad_persona savePersona(@RequestBody entidad_persona PERSONITAS){
        return this.personasService.saveUser(PERSONITAS);
    }

    @GetMapping(path = "/{id}")
    public Optional<entidad_persona> getPersonaById(@PathVariable("id") Long id){
        return this.personasService.getById(id);
    }

    @PutMapping(path = "/{id}")
    public entidad_persona updatePersonaById(@RequestBody entidad_persona request, @PathVariable("id") Long id){
        return this.personasService.updateById(request, id);

    }

    @PostMapping(path = "/IMC")
    public String calculateIMC(@RequestBody entidad_persona persona, @RequestParam String nombreUsuario, @RequestParam String contraseña) {
        if (!authservice.authenticate(nombreUsuario)) {
            return "Debes iniciar sesión para poder calcular tu IMC";
        } else {
            if (persona.getPeso() <= 0) {
                return "El peso no puede ser menor o igual a 0";
            }
            double alturaEnMetros = persona.getEstatura() / 100;
            double IMC = persona.getPeso() / (alturaEnMetros * alturaEnMetros);
            return "Tu IMC es: " + IMC;
        }
    }
    @GetMapping(path = "/{id}/historicoIMC")
    public List<HistoricoIMC> getHistoricoIMC(@PathVariable("id") Long id){
        return this.personasService.getHistoricoIMC(id);
    }


    @DeleteMapping(path = "/{id}")
    public String deletePersonaByiD(@PathVariable("id") Long id){
        boolean ok = this.personasService.DeletePersona(id);
        if(ok){
            return "Persona con id" + id + "Eliminado!";
        }else {
            return "Error, tenemos un problema";
        }
    }

}
