package com.example.act14labuena_.model;

import jakarta.persistence.*;

@Entity
public class HistoricoIMC {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @ManyToOne
    private entidad_persona persona;

    private double imc;

    public HistoricoIMC(entidad_persona persona, double imc) {
        this.persona = persona;
        this.imc = imc;
    }

    public HistoricoIMC() {
    }

}