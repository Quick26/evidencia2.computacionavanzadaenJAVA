package com.example.act14labuena_.model;

import jakarta.persistence.*;
import lombok.Data;

import java.sql.Date;

@Entity
@Data
@Table(name = "PERSONITAS")
public class entidad_persona {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)


    @Column(name = "ID")
    private Long ID;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "apellido")
    private String apellido;

    @Column(name = "edad")
    private int edad;

    @Column(name = "sexo")
    private String sexo;

    @Column(name = "estarura")
    private float estatura;

    @Column(name = "peso")
    private float peso;

    @Column(name = "IMC")
    private float IMC;

    @Column(name = "fecha")
    private String fecha;

    @Column(name = "nombreUsuario")
    private String nombreUsuario;

    @Column(name = "contraseña")
    private String contraseña;

}
