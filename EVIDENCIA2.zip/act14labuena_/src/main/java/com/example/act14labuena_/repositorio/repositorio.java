package com.example.act14labuena_.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.act14labuena_.model.entidad_persona;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface repositorio extends JpaRepository<entidad_persona, Long> {


    Optional<entidad_persona> findByNombreUsuario(String nombreUsuario);
}
