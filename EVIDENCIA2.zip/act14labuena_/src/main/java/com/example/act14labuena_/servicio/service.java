package com.example.act14labuena_.servicio;

import com.example.act14labuena_.model.HistoricoIMC;
import com.example.act14labuena_.model.entidad_persona;
import com.example.act14labuena_.repositorio.repositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
@Service
public class service {

    @Autowired
    repositorio personarepositorio;
    @Autowired
    HistoricoIMC historicoIMC;


    public ArrayList<entidad_persona> getPersonas() {
        return (ArrayList<entidad_persona>) personarepositorio.findAll();
    }

    public entidad_persona saveUser(entidad_persona persona) {
        if (persona.getEdad() < 15) {
            throw new IllegalArgumentException("No se puede registrar a una persona menor de 15 años");
        }
        if (persona.getEstatura() < 1.0 || persona.getEstatura() > 2.5) {
            throw new IllegalArgumentException("No se puede registrar a una persona con una estatura menor a 1 metro o mayor a 2.5 metros");
        }
        return personarepositorio.save(persona);
    }

    public Optional<entidad_persona> getById(Long id) {
        return personarepositorio.findById(id);
    }

    public entidad_persona updateById(entidad_persona request, Long id) {
        entidad_persona persona = personarepositorio.findById(id).get();
        persona.setNombre(request.getNombre());
        persona.setApellido(request.getApellido());
        persona.setEdad(request.getEdad());

        return persona;

    }

    public boolean DeletePersona(Long id) {
        try {
            personarepositorio.deleteById(id);
            return true;
        } catch (Exception e) {
            return false;
        }

    }

    public List<HistoricoIMC> getHistoricoIMC(Long id) {
        return null;
    }
}

