package com.example.act14labuena_;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Act14labuenaApplicationTests {

    @Test
    void contextLoads() {
    }

}
